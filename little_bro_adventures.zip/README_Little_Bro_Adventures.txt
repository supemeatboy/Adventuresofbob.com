LITTLE BRO ADVENTURES
=====================

1. Extract little_bro_adventures.zip if you downloaded the ZIP.
2. Open little_bro_adventures.html in Safari, Chrome, Firefox, or Edge.
3. Tap/click Play. The first tap starts the original synthesized background music.
4. In Settings, choose 2-D Classic or 3-D Adventure View and turn music on/off.

CONTROLS
- Left/right arrows: move
- Space or up arrow: jump
- K: kick the Sand Monster in Level 3
- X: use a collected power-up in Spider Cave
- Touch buttons are included for phones/tablets.

IMPORTANT ABOUT THE Files APP
The iPhone/iPad Files preview does not reliably run interactive HTML games or JavaScript.
Keep the HTML file in Files, then use Share > Open in Safari (or another browser) to play it.
The ZIP is just a convenient package; the HTML file is the game.
Fullscreen is optional and is not needed to play.
